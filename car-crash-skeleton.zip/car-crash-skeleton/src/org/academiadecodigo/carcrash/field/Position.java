package org.academiadecodigo.carcrash.field;

public class Position {

    private int col;
    private int row;
    //private boolean occupiedOrNot;

    //constructor
    public Position(int i, int j){
        col=i;
        row=j;
        //occupiedOrNot=true;
    }

    //getters and setters
    public int getCol() {
        return col;
    }

    public int getRow() {
        return row;
    }

    //public boolean isOccupiedOrNot(){return occupiedOrNot;}

    //public void occupy(){occupiedOrNot=true;}

    //public void makeVacant(){occupiedOrNot=false;}

    public void goUp() {
        if (row > 0) {
            row--;
        }
    }

    public void goDown() {
        if (row < (Field.getHeight() - 1)) {
            row++;
        }
    }

    public void goLeft() {
        if (col > 0) {
            col--;
        }
    }

    public void goRight() {
        if (col < (Field.getWidth() - 1)) {
            col++;
        }
    }


    //other methods
    public void goLeftMinusCol(){
        if (col>0){
        col--;}
    }

    public void goRightPlusCol(){
        col++;
    }

    public void goUpMinusRow(){
        if (row>0){
        row--;}
    }

    public void goDownPlusRow(){
        row++;
    }
}
