package org.academiadecodigo.carcrash.cars;

/**
 * Created by codecadet on 17/05/17.
 */
public enum CarType {
    FIAT(1),
    MUSTANG(2);

    private int speed;

    CarType(int speed){
        this.speed=speed;
    }

    public int getSpeed(){
        return speed;
    }
}
