package org.academiadecodigo.carcrash.cars;

import org.academiadecodigo.carcrash.field.Position;

/**
 * Created by codecadet on 17/05/17.
 */
public class Fiat extends Car {



    //constructor
    public Fiat( Position pos){
        super(CarType.FIAT, pos);
    }


    public String toString(){
        if(isCrashed()){
            return "C";
        } else{
        return "F";}
    }
}
