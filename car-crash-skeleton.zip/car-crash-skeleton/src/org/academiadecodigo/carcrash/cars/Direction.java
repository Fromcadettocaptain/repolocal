package org.academiadecodigo.carcrash.cars;

/**
 * Created by codecadet on 17/05/17.
 */
public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT;

    public Direction oppositeDir(){
        switch (this){
            case RIGHT:
                return LEFT;
            case LEFT:
                return RIGHT;
            case UP:
                return DOWN;
            case DOWN:
                return UP;

        } return null;
    }
}
