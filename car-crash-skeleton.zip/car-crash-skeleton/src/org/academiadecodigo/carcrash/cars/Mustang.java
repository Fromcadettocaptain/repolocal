package org.academiadecodigo.carcrash.cars;

import org.academiadecodigo.carcrash.field.Position;

/**
 * Created by codecadet on 17/05/17.
 */
public class Mustang extends Car {


    ////constructor
    public Mustang(Position pos){
        super(CarType.MUSTANG, pos);
    }


    public String toString(){
        if(isCrashed()){
            return "C";
        } else{
        return "M";}
    }
}
