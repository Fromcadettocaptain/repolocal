package org.academiadecodigo.carcrash.cars;

import org.academiadecodigo.carcrash.field.Field;
import org.academiadecodigo.carcrash.field.Position;

abstract public class Car {

    private CarType carType;
    private boolean crashedOrNot;
    private Direction lastdirection;

    /**
     * The position of the car on the grid
     */
    private Position pos;

    //constructor
    public Car(CarType carType, Position pos) {
        this.carType = carType;
        this.pos = pos;
        crashedOrNot = false;
        lastdirection=null;
    }


    //getters, setters, and setter-type methods
    public Position getPos() {
        return pos;
    }

    public boolean isCrashed() {
        return crashedOrNot;
    }

    public void crash() {
        crashedOrNot = true;
    }

    public CarType getCarType(){ return carType;}

    private void moveindir(Direction dir){
        switch (dir) {
            case UP:
                pos.goUp();
                break;
            case DOWN:
                pos.goDown();
                break;
            case LEFT:
                pos.goLeft();
                break;
            case RIGHT:
                pos.goRight();
                break;
        }
    }

    private Direction movetosides(Direction dir){
        int rnd=(int)(Math.random()*2);
            if(dir==Direction.UP || dir==Direction.DOWN) {
                if (rnd == 0) {
                    moveindir(Direction.LEFT);
                    return Direction.LEFT;
                } else { moveindir(Direction.RIGHT);
                return Direction.RIGHT;}
            }
            if(dir==Direction.LEFT || dir==Direction.RIGHT){
                if(rnd==0){
                    moveindir(Direction.UP);
                    return Direction.UP;
                } else { moveindir(Direction.DOWN);
                return Direction.DOWN;}
            } return null;
    }


    public void move() {
        if (!isCrashed()) {
            if (lastdirection==null){
                Direction rnddirection = Direction.values()[(int) (Math.random() * 4)];
                moveindir(rnddirection);
            } else {
                int rndinterval=(int)(Math.random()*10);
                if(rndinterval>=0 && rndinterval<5){
                    moveindir(lastdirection);
                } else if (rndinterval==9){
                    moveindir(lastdirection.oppositeDir());
                    lastdirection=lastdirection.oppositeDir();
                } else lastdirection=movetosides(lastdirection);
            }
        }
    }

    public abstract String toString();
}
