package org.academiadecodigo.carcrash.cars;

import org.academiadecodigo.carcrash.field.Field;
import org.academiadecodigo.carcrash.field.Position;

public class CarFactory {

    public static  Car getNewCar() {
        Position carpos= new Position((int) (Math.random()*Field.getWidth()),(int) (Math.random()* Field.getHeight()));
        int decidecar=(int)(Math.random()*2);
        if (decidecar==0){
        return new Fiat(carpos);
        } else{
            return new Mustang(carpos);
        }
    }
}
